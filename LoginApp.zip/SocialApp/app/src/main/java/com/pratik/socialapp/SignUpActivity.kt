package com.pratik.socialapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase

class SignUpActivity : AppCompatActivity() {
    lateinit var etcreateemail:EditText
    lateinit var etcreatepassword:EditText
    lateinit var etconfirmpassword:EditText
    lateinit var btnsignup:Button
    lateinit var txtalreadyregistered:TextView
    lateinit var etname:EditText

    private lateinit var auth: FirebaseAuth
    private lateinit var db:FirebaseFirestore


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        auth= FirebaseAuth.getInstance()
        db= FirebaseFirestore.getInstance()


        etcreateemail=findViewById(R.id.etcreateemail)
        etcreatepassword=findViewById(R.id.etcreatepassword)
        etconfirmpassword=findViewById(R.id.etconfirmpassword)
        btnsignup=findViewById(R.id.btnsignup)
        txtalreadyregistered=findViewById(R.id.txtalreadyregistered)
        etname=findViewById(R.id.etname)


        btnsignup.setOnClickListener {
            if(checking())
            {
                val name=etname.text.toString()
                val email2=etcreateemail.text.toString()
                val password2=etcreatepassword.text.toString()
                val confirmpassword2=etconfirmpassword.text.toString()

                if(password2.equals(confirmpassword2))
                {
                    val user= hashMapOf(
                        "Name" to name,
                        "Email" to email2
                    )

                    val users=db.collection("USERS")
                    val query=users.whereEqualTo("Email",email2).get()
                        .addOnSuccessListener {
                            tasks->
                            if(tasks.isEmpty)
                            {
                                auth.createUserWithEmailAndPassword(email2,password2)
                                    .addOnCompleteListener(this)
                                    {
                                        task->
                                        if(task.isSuccessful)
                                        {
                                            users.document(email2).set(user)
                                            val intent=Intent(this,LoggedInActivity::class.java)
                                            intent.putExtra("Email",email2)
                                            startActivity(intent)
                                            finish()

                                        }
                                        else
                                        {
                                            Toast.makeText(this,"Authentication Failed ",Toast.LENGTH_SHORT).show()

                                        }
                                    }
                            }
                            else
                            {
                                Toast.makeText(
                                    this,
                                    "User Already Registered",
                                    Toast.LENGTH_SHORT
                                ).show()
                                val intent=Intent(this,MainActivity::class.java)
                                startActivity(intent)

                            }
                        }

                }
                else {
                    Toast.makeText(
                        this,
                        "Password And Confirm Password Do Not Match",
                        Toast.LENGTH_SHORT
                    ).show()
                }




            }
            else
            {
                Toast.makeText(this,"Enter All Details",Toast.LENGTH_SHORT).show()
            }

            txtalreadyregistered.setOnClickListener {
                val intent= Intent(this,LoggedInActivity::class.java)
                startActivity(intent)
            }
        }


    }
    private fun checking():Boolean{
        if(etcreateemail.text.toString().trim { it<=' ' }.isNotEmpty()
            && etcreatepassword.text.toString().trim { it<=' ' }.isNotEmpty()
            && etconfirmpassword.text.toString().trim { it<=' ' }.isNotEmpty()
        )
        {
            return true
        }
        else
        {
            return false
        }
    }


}