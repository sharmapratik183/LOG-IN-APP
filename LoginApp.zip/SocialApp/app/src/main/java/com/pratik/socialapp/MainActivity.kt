package com.pratik.socialapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {
    private lateinit var auth:FirebaseAuth
    private lateinit var etemail:EditText
    private lateinit var etpassword:EditText
    private lateinit var btnlogin:Button
    private lateinit var txtregister:TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        auth= FirebaseAuth.getInstance()
        etemail=findViewById(R.id.etemail)
        etpassword=findViewById(R.id.etpassword)
        btnlogin=findViewById(R.id.btnlogin)
        txtregister=findViewById(R.id.txtregister)

        txtregister.setOnClickListener {
            val intent=Intent(this,SignUpActivity::class.java)
            startActivity(intent)
            finish()
        }

        btnlogin.setOnClickListener {
            if(checking())
            {
                val email=etemail.text.toString()
                val password=etpassword.text.toString()
                auth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this)
                    {
                        task->
                        if(task.isSuccessful)
                        {
                            val intent= Intent(this,LoggedInActivity::class.java)
                            intent.putExtra("Email",email)
                            startActivity(intent)
                            finish()

                        }
                        else
                        {
                            Toast.makeText(this,"Wrong Details",Toast.LENGTH_SHORT).show()

                        }
                    }

            }
            else{
                Toast.makeText(this,"Please Enter The Details",Toast.LENGTH_SHORT).show()
            }


        }
    }

    private fun checking():Boolean
    {
        if(etemail.text.toString().trim { it<=' ' }.isNotEmpty() && etpassword.text.toString().trim { it<=' ' }.isNotEmpty())
        {
            return true
        }
        else
        {
            return false
        }
    }
}